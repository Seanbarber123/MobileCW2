package com.example.com594cw22020;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.RecoverySystem;
import android.provider.MediaStore;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.google.android.gms.vision.Frame;
import com.google.android.gms.vision.face.Face;
import com.google.android.gms.vision.face.FaceDetector;

public class CameraScan extends AppCompatActivity {

    ImageView imageView2;
    Button button_CameraScan;

    //Request Camera Code
    private static final int CAMERA_REQUEST =1;

    //Request Gallery Code
    private static final int GALLERY_REQUEST =2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera_scan);

        imageView2 = findViewById(R.id.imageView2);
        button_CameraScan = findViewById(R.id.button_CameraScan);

        button_CameraScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showImageOptionDialog();
            }
        });
    }

    private void showImageOptionDialog(){
        final String[] options = {"Take Picture with Camera", "Choose from Gallery"};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select Image Option");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which){
                    case 0:
                        // Take Photo from Camera
                        captureFromCamera();
                        break;
                    case 1:
                        //Get Image from Gallery
                        getImageFromGallery();
                        break;
                }
            }
        });
        builder.show();
    }

    public void captureFromCamera(){
        Intent cameraIntent = new Intent();
        cameraIntent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(cameraIntent,CAMERA_REQUEST);
    }

    //Open Phone Gallery
    public void getImageFromGallery(){
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(intent, GALLERY_REQUEST);
    }

    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        //Check if the intent was succesful, and will then pick the image
        if(requestCode == GALLERY_REQUEST && resultCode == RESULT_OK && data != null){
            //Get selected image URI from Gallery
            Uri selectedImage = data.getData();
            //Display selected photo in Image View
            imageView2.setImageURI(selectedImage);
        }
        //Handle Camera Request
        if(requestCode == CAMERA_REQUEST && resultCode == RESULT_OK && data != null){
            //Bitmap vairable to store the photo
            Bitmap bitmap = (Bitmap) data.getExtras().get("Data");
            //Display photo in the image view
            imageView2.setImageBitmap(bitmap);
        }
    }

    public void detectFaces (View view){
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inMutable = true;

        //Bitmap myBitmap = BitmapFactory.decodeResource(getApplicationContext().getResources(),
               // R.drawable.test1, options);

        BitmapDrawable drawable = (BitmapDrawable) imageView2.getDrawable();
        Bitmap myBitmap = drawable.getBitmap();

        Paint myRectPaint = new Paint();
        myRectPaint.setStrokeWidth(15);
        myRectPaint.setColor(Color.GREEN);
        myRectPaint.setStyle(Paint.Style.STROKE);

        Bitmap tempBitmap = Bitmap.createBitmap(myBitmap.getWidth(), myBitmap.getHeight(),
                Bitmap.Config.RGB_565);
        Canvas tempCanvas = new Canvas(tempBitmap);
        tempCanvas.drawBitmap(myBitmap, 0, 0, null);

        FaceDetector faceDetector = new FaceDetector.Builder(getApplicationContext())
                .setTrackingEnabled(false).build();
        if(!faceDetector.isOperational()){
            new AlertDialog.Builder(this)
                    .setMessage("Could not set up the face detector").show();
            return;
        }

        Frame frame = new Frame.Builder().setBitmap(myBitmap).build();
        SparseArray<Face> faces = faceDetector.detect(frame);
        Log.d("TEST", "Num Faces = " + faces.size());

        for(int i=0; i< faces.size(); i++){
            Face thisFace = faces.valueAt(i);

            float x1 = thisFace.getPosition().x;
            float y1 = thisFace.getPosition().y;
            float x2 = x1 + thisFace.getWidth();
            float y2 = y1 + thisFace.getHeight();
            tempCanvas.drawRoundRect(new RectF(x1,y1, x2, y2), 2, 2, myRectPaint);
        }

        imageView2.setImageDrawable(new BitmapDrawable(getResources(),tempBitmap));

        if(faces.size() <1) {
            new AlertDialog.Builder(this)
                    .setMessage("Hey, there's no face in this photo").show();
        }else if (faces.size()==1){
            new AlertDialog.Builder(this)
                    .setMessage("Hey, there is one face in this photo").show();
        }else if (faces.size()==1) {
            new AlertDialog.Builder(this)
                    .setMessage("Hey, there's more than one face in this photo").show();
        }
    }

    public void goMainMenu(View view){
        startActivity(new Intent(CameraScan.this, MenuActivity.class));
    }
}