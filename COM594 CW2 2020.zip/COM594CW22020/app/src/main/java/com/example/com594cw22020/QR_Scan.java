package com.example.com594cw22020;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.vision.Frame;
import com.google.android.gms.vision.barcode.BarcodeDetector;
import com.google.android.gms.vision.barcode.Barcode;


public class QR_Scan extends AppCompatActivity {

    ImageView imageView3;
    Button button_QRScan;

    //Request Camera Code
    private static final int CAMERA_REQUEST =1;

    //Request Gallery Code
    private static final int GALLERY_REQUEST =2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q_r__scan);

        imageView3 = findViewById(R.id.imageView3);
        button_QRScan = findViewById(R.id.button_QRScan);

        button_QRScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showImageOptionDialog();
            }
        });
    }

    private void showImageOptionDialog(){
        final String[] options = {"Take Picture with Camera", "Choose from Gallery"};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select Image Option");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which){
                    case 0:
                        // Take Photo from Camera
                        captureFromCamera();
                        break;
                    case 1:
                        //Get Image from Gallery
                        getImageFromGallery();
                        break;
                }
            }
        });
        builder.show();
    }

    public void captureFromCamera(){
        Intent cameraIntent = new Intent();
        cameraIntent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(cameraIntent,CAMERA_REQUEST);
    }

    //Open Phone Gallery
    public void getImageFromGallery(){
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(intent, GALLERY_REQUEST);
    }

    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        //Check if the intent was succesful, and will then pick the image
        if(requestCode == GALLERY_REQUEST && resultCode == RESULT_OK && data != null){
            //Get selected image URI from Gallery
            Uri selectedImage = data.getData();
            //Display selected photo in Image View
            imageView3.setImageURI(selectedImage);
        }
        //Handle Camera Request
        if(requestCode == CAMERA_REQUEST && resultCode == RESULT_OK && data != null){
            //Bitmap vairable to store the photo
            Bitmap bitmap = (Bitmap) data.getExtras().get("Data");
            //Display photo in the image view
            imageView3.setImageBitmap(bitmap);
        }
    }

    public void processBarcode(View view){
        Bitmap myBitmap1 = BitmapFactory.decodeResource(
                getApplicationContext().getResources(),
                R.drawable.barcode);


        TextView textView = findViewById(R.id.textViewQR);
        BarcodeDetector detector = new BarcodeDetector.Builder(getApplicationContext())
               .setBarcodeFormats(Barcode.DATA_MATRIX | Barcode.QR_CODE).build();
        if (!detector.isOperational()){
            textView.setText("Could not set up detector!");
            return;
        }

        Frame frame = new Frame.Builder().setBitmap(myBitmap1).build();
        SparseArray<Barcode> barcodes = detector.detect(frame);

        Barcode thisCode = barcodes.valueAt(0);
        Log.d("Barcode", thisCode.rawValue);
        textView.setText(thisCode.rawValue);
    }
}