package com.example.com594cw22020;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
    }

    public void goQRCode(View view){
        startActivity(new Intent(MenuActivity.this, QR_Scan.class));
    }

    public void goCameraPhoto(View view){
        startActivity(new Intent(MenuActivity.this, CameraScan.class));
    }
}