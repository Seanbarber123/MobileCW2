package com.example.com594cw22020;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;

public class MainActivity extends AppCompatActivity {

    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        firebaseAuth = FirebaseAuth.getInstance();
    }

    public void UserLogIn(View View){
        String email = ((EditText) findViewById(R.id.EmailLogIn)).getText().toString();
        String password = ((EditText) findViewById(R.id.PasswordLogIn)).getText().toString();

        //Checking if email and password are empty
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(this, "Please enter Email", Toast.LENGTH_LONG).show();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please enter Password", Toast.LENGTH_LONG).show();
            return;
        }

        //Creating new user
        firebaseAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(MainActivity.this, "Log In Succesful",
                                    Toast.LENGTH_LONG).show();
                            startActivity(new Intent(MainActivity.this, MenuActivity.class));
                            finish();
                        }else{
                            FirebaseAuthException e = (FirebaseAuthException) task.getException();
                            Toast.makeText(MainActivity.this, "Log In Error: "
                                    + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                });

    }

    public void goSignUp(View view){
        startActivity(new Intent(MainActivity.this, SignUp.class));
    }
}